// Simple app logic for demo PWA panel
const LS = { admins:'brj_admins', logs:'brj_logs', cands:'brj_cands', user:'brj_user' };
if(!localStorage.getItem(LS.admins)){
  const seed = [
    {id:'u1',name:'Owner',username:'Owner',password:'Owner2025',role:'Owner'},
    {id:'u2',name:'Líder',username:'lider',password:'1234',role:'Líder'},
    {id:'u3',name:'Admin',username:'admin',password:'1234',role:'Administrador'}
  ];
  localStorage.setItem(LS.admins, JSON.stringify(seed));
}
if(!localStorage.getItem(LS.logs)) localStorage.setItem(LS.logs, JSON.stringify([]));
if(!localStorage.getItem(LS.cands)) localStorage.setItem(LS.cands, JSON.stringify([]));

function $(s){ return document.querySelector(s); }
function renderInitial(){ 
  const user = JSON.parse(localStorage.getItem(LS.user) || 'null');
  if(!user){ showLogin(); } else { showPanel(user); }
  if('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(()=>{});
}
function showLogin(){
  document.body.innerHTML = `
  <div style="min-height:100vh;display:grid;place-items:center;background:linear-gradient(180deg,#071b15,#041612)">
    <div style="width:360px">
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px">
        <img src="icons/icon-192.png" style="width:56px;height:56px;border-radius:12px"/>
        <div><div style="font-weight:700">Brasil RJ Role Play</div><div style="color:#8fb8a0;font-size:13px">Painel administrativo</div></div>
      </div>
      <div style="background:#06231c;padding:18px;border-radius:12px">
        <input id="u" placeholder="Usuário" class="input" style="width:100%;margin-bottom:8px"/>
        <input id="p" placeholder="Senha" type="password" class="input" style="width:100%;margin-bottom:12px"/>
        <div style="display:flex;gap:8px">
          <button class="btn primary" id="loginBtn">Entrar</button>
          <button class="btn" id="prefill">Preencher</button>
        </div>
        <div style="color:#9dbfa9;font-size:13px;margin-top:10px">Owner: <b>Owner</b> / <b>Owner2025</b></div>
      </div>
    </div>
  </div>`;
  document.getElementById('prefill').addEventListener('click', ()=>{ $('#u').value='Owner'; $('#p').value='Owner2025'; });
  document.getElementById('loginBtn').addEventListener('click', ()=>{ const u=$('#u').value.trim(), p=$('#p').value.trim(); const admins=JSON.parse(localStorage.getItem(LS.admins)); const found = admins.find(a=>a.username===u && a.password===p); if(!found){ alert('Credenciais inválidas'); return; } localStorage.setItem(LS.user, JSON.stringify(found)); showPanel(found); });
}

function showPanel(user){
  document.body.innerHTML = `
  <div class="wrap">
    <div class="header">
      <div class="logo"><img src="icons/icon-192.png" style="width:100%;height:100%;object-fit:cover" /></div>
      <div class="title">Brasil RJ Role Play — Painel</div>
      <div style="margin-left:auto;display:flex;gap:8px;align-items:center">
        <div class="badge">Usuário: ${user.name}</div>
        <button class="btn" id="logout">Sair</button>
      </div>
    </div>
    <div class="grid">
      <div>
        <div class="card">
          <div style="display:flex;justify-content:space-between;align-items:center">
            <div style="font-weight:700">Visão Geral</div>
            <div class="controls"><input id="q" class="input" placeholder="Buscar..."/><button class="btn primary" id="newCand">Nova Entrevista</button></div>
          </div>
          <div class="statrow" style="margin-top:12px">
            <div class="stat"><div class="num" id="sLogs">0</div><div class="muted">Logs</div></div>
            <div class="stat"><div class="num" id="sOk">0</div><div class="muted">Aprovados</div></div>
            <div class="stat"><div class="num" id="sPend">0</div><div class="muted">Pendentes</div></div>
            <div class="stat"><div class="num" id="sAdmins">0</div><div class="muted">Admins</div></div>
          </div>
        </div>
        <div class="card" style="margin-top:14px">
          <div style="font-weight:700">Entrevistas recentes</div>
          <table class="table" id="tblCands"><thead><tr><th>Data</th><th>Nome</th><th>Cargo</th><th>Status</th></tr></thead><tbody></tbody></table>
        </div>
      </div>
      <div>
        <div class="card">
          <div style="display:flex;justify-content:space-between;align-items:center"><div style="font-weight:700">Logs</div><button class="btn" id="openLog">Novo</button></div>
          <div style="margin-top:10px"><table class="table" id="tblLogs"><thead><tr><th>Data</th><th>Ação</th><th>Usuário</th></tr></thead><tbody></tbody></table></div>
        </div>
        <div class="card" style="margin-top:12px"><div style="font-weight:700">Administradores</div><div id="adminsList" style="margin-top:10px"></div></div>
      </div>
    </div>
    <div class="footer">© Brasil RJ Role Play</div>
  </div>`;

  document.getElementById('logout').addEventListener('click', ()=>{ localStorage.removeItem(LS.user); renderInitial(); });
  document.getElementById('newCand').addEventListener('click', ()=> openCandModal());
  document.getElementById('openLog').addEventListener('click', ()=> openLogModal());
  document.getElementById('q').addEventListener('input', renderPanel);
  renderPanel();
}

function renderPanel(){
  const cands = JSON.parse(localStorage.getItem(LS.cands) || '[]');
  const logs = JSON.parse(localStorage.getItem(LS.logs) || '[]');
  const admins = JSON.parse(localStorage.getItem(LS.admins) || '[]');
  $('#sLogs').textContent = logs.length;
  $('#sOk').textContent = cands.filter(c=>c.status==='Aprovado').length;
  $('#sPend').textContent = cands.filter(c=>c.status==='Pendente').length;
  $('#sAdmins').textContent = admins.length;
  const qb = $('#q').value.trim().toLowerCase();
  const tb = document.querySelector('#tblCands tbody'); tb.innerHTML='';
  cands.filter(c=>!qb || (c.name + ' ' + c.desiredRole + ' ' + c.status).toLowerCase().includes(qb)).slice(0,12).forEach(c=>{
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${new Date(c.ts).toLocaleString()}</td><td>${c.name}</td><td>${c.desiredRole}</td><td>${c.status}</td>`;
    tb.appendChild(tr);
  });
  const tl = document.querySelector('#tblLogs tbody'); tl.innerHTML=''; logs.slice(0,12).forEach(l=>{ const tr=document.createElement('tr'); tr.innerHTML=`<td>${new Date(l.ts).toLocaleString()}</td><td>${l.action}</td><td>${l.actor}</td>`; tl.appendChild(tr); });
  const al = $('#adminsList'); al.innerHTML=''; admins.forEach(a=>{ const d=document.createElement('div'); d.style.display='flex'; d.style.justifyContent='space-between'; d.style.marginBottom='6px'; d.innerHTML = `<div><strong>${a.name}</strong><div style="font-size:12px;color:#8fb8a0">${a.username} • ${a.role}</div></div><div><button class="btn" onclick="impersonate('${a.id}')">Entrar</button></div>`; al.appendChild(d); });
}

function openLogModal(){
  const action = prompt('Ação (ex: Alterou permissão)'); if(!action) return;
  const details = prompt('Detalhes (opcional)');
  const logs = JSON.parse(localStorage.getItem(LS.logs)||'[]'); logs.unshift({id:uid(), actor: JSON.parse(localStorage.getItem(LS.user)).name, action, details, ts: Date.now()}); localStorage.setItem(LS.logs, JSON.stringify(logs)); renderPanel();
}

function openCandModal(){
  const name = prompt('Nome do entrevistado'); if(!name) return;
  const desired = prompt('Cargo desejado','Administrador'); const notes = prompt('Notas (opcional)'); const c = { id:uid(), name, desiredRole:desired, interviewer: JSON.parse(localStorage.getItem(LS.user)).name, notes, status:'Pendente', ts: Date.now() };\n  const arr = JSON.parse(localStorage.getItem(LS.cands)||'[]'); arr.unshift(c); localStorage.setItem(LS.cands, JSON.stringify(arr)); renderPanel();
}

function actionCand(id,status){ const arr = JSON.parse(localStorage.getItem(LS.cands)||'[]'); const c = arr.find(x=>x.id===id); if(!c) return; c.status=status; localStorage.setItem(LS.cands, JSON.stringify(arr)); renderPanel(); }

function impersonate(id){ const admins = JSON.parse(localStorage.getItem(LS.admins)||'[]'); const u = admins.find(a=>a.id===id); if(!u) return; localStorage.setItem(LS.user, JSON.stringify(u)); renderInitial(); }

function uid(){ return crypto.randomUUID?crypto.randomUUID():('id-'+Math.random().toString(36).slice(2)); }

window.addEventListener('load', renderInitial);
